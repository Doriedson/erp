<?php
namespace App\Http\Controllers;

use App\Repositories\OrderRepository;

final class OrderController
{
    public function __construct(private OrderRepository $repo = new OrderRepository()) {}

    /** Helper simples p/ JSON */
    private function json(mixed $data, int $code = 200): array {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        return $data;
    }

    /** GET /api/orders?limit=20&offset=0&q=texto */
    public function index(): array {

        $limit  = (int)($_GET['limit']  ?? 20);
        $offset = (int)($_GET['offset'] ?? 0);
        $q      = (string)($_GET['q'] ?? '');

        // NOVO: sort/dir
        $sort   = (string)($_GET['sort'] ?? 'data');   // aceita 'id','data','cliente','status','frete','servico','mais_recente','mais_antigo'
        $dir    = (string)($_GET['dir']  ?? 'desc');   // 'asc'|'desc'

        $out = $this->repo->list([
            'limit'  => $limit,
            'offset' => $offset,
            'q'      => $q,
            'sort'   => $sort,
            'dir'    => $dir,
        ]);

        // (opcional) headers de paginação
        header('X-Total: ' . $out['total']);
        header('X-Limit: ' . $out['limit']);
        header('X-Offset: ' . $out['offset']);

        return $this->json($out);
    }

    /**
     * POST /api/orders
     * Aceita:
     *  - id_vendastatus (int) OU vendastatus (string)
     *  - id_colaborador (int)  [obrigatório]
     *  - id_entidade, id_caixa, frete, valor_servico, obs, mesa, versao
     */
    public function store(): array {
        $raw  = file_get_contents('php://input') ?: '{}';
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return $this->json(['error' => 'JSON inválido'], 400);
        }

        // validações amigáveis (sem parar no DB)
        if (!isset($data['id_vendastatus']) && !isset($data['vendastatus'])) {
            return $this->json(['error' => 'Informe id_vendastatus (int) ou vendastatus (string).'], 422);
        }
        if (empty($data['id_colaborador'])) {
            return $this->json(['error' => 'id_colaborador é obrigatório.'], 422);
        }

        try {
            $id = $this->repo->create($data);
            return $this->json(['id_venda' => $id], 201);
        } catch (\InvalidArgumentException $e) {
            return $this->json(['error' => $e->getMessage()], 422);
        } catch (\Throwable $e) {
            // Logue $e->getMessage() num logger se houver
            return $this->json(['error' => 'Erro ao criar venda'], 500);
        }
    }

    /**
     * PATCH /api/orders/{id}/status
     * Body:
     *   - id_vendastatus (int) OU vendastatus (string)
     */
    public function updateStatus(int $id): array {
        $raw  = file_get_contents('php://input') ?: '{}';
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return $this->json(['error' => 'JSON inválido'], 400);
        }

        if (!isset($data['id_vendastatus']) && !isset($data['vendastatus'])) {
            return $this->json(['error' => 'Informe id_vendastatus (int) ou vendastatus (string).'], 422);
        }

        try {
            if (isset($data['id_vendastatus'])) {
                $ok = $this->repo->updateStatus($id, (int)$data['id_vendastatus']);
            } else {
                // aceita nome do status
                $ok = $this->repo->updateStatusByName($id, (string)$data['vendastatus']);
            }
            return $this->json(['ok' => (bool)$ok]);
        } catch (\InvalidArgumentException $e) {
            return $this->json(['error' => $e->getMessage()], 422);
        } catch (\Throwable $e) {
            return $this->json(['error' => 'Erro ao atualizar status'], 500);
        }
    }
}
