<?php
namespace App\Repositories;

use App\Database\Connection;
use PDO;

final class OrderRepository {
    private PDO $pdo;

    // Habilitar/desabilitar joins extras
    private bool $withCliente = true;
    private bool $withStatus  = true;

    public function __construct() {
        $this->pdo = Connection::pdo();
    }

    /** Colunas selecionadas (nomenclatura nativa) */
    private function selectColumns(): string {
        $cols = [
            "v.id_venda",
            "v.id_vendastatus",
            "v.id_entidade",
            "v.id_colaborador",
            "v.id_caixa",
            "v.`data`",
            "v.frete",
            "v.valor_servico",
            "v.obs",
            "v.mesa",
            "v.versao",
        ];

        if ($this->withCliente) {
            $cols[] = "e.nome            AS cliente_nome";
            $cols[] = "e.email           AS cliente_email";
            $cols[] = "e.telcelular      AS cliente_telcelular";
            $cols[] = "e.telresidencial  AS cliente_telresidencial";
            $cols[] = "e.telcomercial    AS cliente_telcomercial";
        }

        if ($this->withStatus) {
            $cols[] = "s.vendastatus";
        }

        return implode(",\n                ", $cols);
    }

    /** JOINs opcionais */
    private function joinClause(): string {
        $joins = [];
        if ($this->withCliente) {
            $joins[] = "LEFT JOIN tab_entidade e ON e.id_entidade = v.id_entidade";
        }
        if ($this->withStatus) {
            $joins[] = "LEFT JOIN tab_vendastatus s ON s.id_vendastatus = v.id_vendastatus";
        }
        return $joins ? "\n" . implode("\n", $joins) : '';
    }

    /** Lista paginada com busca */
    public function list(array $opts = []): array {

        $limit  = max(1, min(100, (int)($opts['limit']  ?? 20)));
        $offset = max(0, (int)($opts['offset'] ?? 0));
        $q      = trim((string)($opts['q'] ?? ''));

        // ---- NOVO: SORT SEGURO (whitelist) ----
        $sortIn  = (string)($opts['sort'] ?? 'data');   // default
        $dirIn   = (string)($opts['dir']  ?? 'desc');   // default

        // atalhos
        if ($sortIn === 'mais_recente') { $sortIn = 'data'; $dirIn = 'desc'; }
        if ($sortIn === 'mais_antigo')  { $sortIn = 'data'; $dirIn = 'asc';  }

        // map de campos -> coluna SQL
        $sortable = [
            'id'      => 'v.id_venda',
            'data'    => 'v.`data`',
            'cliente' => 'e.nome',           // requer $withCliente = true
            'status'  => 's.vendastatus',    // requer $withStatus  = true
            'frete'   => 'v.frete',
            'servico' => 'v.valor_servico',
        ];

        $col = $sortable[$sortIn] ?? 'v.`data`';
        $dir = (strtolower($dirIn) === 'asc') ? 'ASC' : 'DESC';

        // se ordenar por colunas de join, garanta os joins ligados
        if (($col === 'e.nome') && !$this->withCliente)  { $this->withCliente = true; }
        if (($col === 's.vendastatus') && !$this->withStatus) { $this->withStatus = true; }
        // ---------------------------------------


        $whereParts = [];
        $positionalBinds = []; // valores na ordem dos "?" na query

        if ($q !== '') {
            $needle = '%'.$q.'%';
            $like = ["v.obs LIKE ?", "v.mesa LIKE ?"];
            $positionalBinds[] = $needle;
            $positionalBinds[] = $needle;

            if ($this->withCliente) {
                $like[] = "e.nome LIKE ?";
                $like[] = "e.email LIKE ?";
                $like[] = "e.telcelular LIKE ?";
                $like[] = "e.telresidencial LIKE ?";
                $like[] = "e.telcomercial LIKE ?";
                array_push($positionalBinds, $needle, $needle, $needle, $needle, $needle);
            }
            if ($this->withStatus) {
                $like[] = "s.vendastatus LIKE ?";
                $positionalBinds[] = $needle;
            }
            $whereParts[] = '(' . implode(' OR ', $like) . ')';
        }

        $where = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

        // Interpola LIMIT/OFFSET como inteiros (seguros)
        $sql = "SELECT
            {$this->selectColumns()}
            FROM tab_venda v
            {$this->joinClause()}
            {$where}
            ORDER BY {$col} {$dir}, v.id_venda DESC
            LIMIT {$limit} OFFSET {$offset}";


        $st = $this->pdo->prepare($sql);

        // Bind posicional na ordem dos "?"
        foreach ($positionalBinds as $i => $val) {
            $st->bindValue($i + 1, $val, PDO::PARAM_STR);
        }

        $st->execute();
        $items = $st->fetchAll(PDO::FETCH_ASSOC);

        // COUNT com a MESMA lógica de binds posicionais
        $countSql = "SELECT COUNT(*) FROM tab_venda v {$this->joinClause()} {$where}";
        $stc = $this->pdo->prepare($countSql);
        foreach ($positionalBinds as $i => $val) {
            $stc->bindValue($i + 1, $val, PDO::PARAM_STR);
        }
        $stc->execute();
        $total = (int)$stc->fetchColumn();

        return ['items'=>$items, 'total'=>$total, 'limit'=>$limit, 'offset'=>$offset];
    }

    /** Cria venda (status e colaborador obrigatórios) */
    public function create(array $data): int {
        if (!isset($data['id_vendastatus']) && !isset($data['vendastatus'])) {
            throw new \InvalidArgumentException('id_vendastatus (ou vendastatus) é obrigatório');
        }
        if (empty($data['id_colaborador'])) {
            throw new \InvalidArgumentException('id_colaborador é obrigatório');
        }

        // Se veio nome do status, converte para ID
        if (!isset($data['id_vendastatus']) && isset($data['vendastatus'])) {
            $st = $this->pdo->prepare(
                "SELECT id_vendastatus FROM tab_vendastatus WHERE vendastatus = :nome LIMIT 1"
            );
            $st->execute(['nome' => $data['vendastatus']]);
            $id = $st->fetchColumn();
            if (!$id) {
                throw new \InvalidArgumentException('vendastatus inválido: '.$data['vendastatus']);
            }
            $data['id_vendastatus'] = (int)$id;
        }

        $sql = "INSERT INTO tab_venda
                (id_vendastatus, id_entidade, id_colaborador, id_caixa,
                 frete, valor_servico, obs, mesa, versao)
                VALUES
                (:id_vendastatus, :id_entidade, :id_colaborador, :id_caixa,
                 :frete, :valor_servico, :obs, :mesa, :versao)";

        $st = $this->pdo->prepare($sql);
        $st->execute([
            'id_vendastatus' => (int)$data['id_vendastatus'],
            'id_entidade'    => $data['id_entidade']    ?? null,
            'id_colaborador' => (int)$data['id_colaborador'],
            'id_caixa'       => $data['id_caixa']       ?? null,
            'frete'          => $data['frete']          ?? 0,
            'valor_servico'  => $data['valor_servico']  ?? 0,
            'obs'            => $data['obs']            ?? '',
            'mesa'           => $data['mesa']           ?? '',
            'versao'         => $data['versao']         ?? 0,
        ]);

        return (int)$this->pdo->lastInsertId();
    }

    /** Atualiza status por ID */
    public function updateStatus(int $id_venda, int $id_vendastatus): bool {
        $st = $this->pdo->prepare(
            "UPDATE tab_venda
             SET id_vendastatus = :s
             WHERE id_venda = :id"
        );
        return $st->execute(['s'=>$id_vendastatus, 'id'=>$id_venda]);
    }

    /** Atualiza status por nome (vendastatus) */
    public function updateStatusByName(int $id_venda, string $vendastatus): bool {
        $sql = "UPDATE tab_venda v
                JOIN tab_vendastatus s ON s.id_vendastatus = v.id_vendastatus
                SET v.id_vendastatus = (
                    SELECT s2.id_vendastatus
                    FROM tab_vendastatus s2
                    WHERE s2.vendastatus = :nome
                    LIMIT 1
                )
                WHERE v.id_venda = :id";
        $st = $this->pdo->prepare($sql);
        return $st->execute(['nome'=>$vendastatus, 'id'=>$id_venda]);
    }
}
