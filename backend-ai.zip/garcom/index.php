<?php

header("Location: ../waiter.php");