<?php
declare(strict_types=1);

ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../vendor/autoload.php';

use App\Support\DotenvLoader;
use App\Http\Router;
use App\Http\Controllers\OrderController;

DotenvLoader::boot(__DIR__ . '/../');

$router = new Router();
$router->get('/health', fn() => ['ok' => true]);

$router->mount('/api', function(App\Http\Router $r){
    $r->get('/orders', [App\Http\Controllers\OrderController::class, 'index']);
    $r->post('/orders', [App\Http\Controllers\OrderController::class, 'store']);
});

// Home
$router->get('/', fn() => ['ok'=>true,'endpoints'=>['/health','/api/orders']]);

// Health
$router->get('/health', fn() => ['ok' => true]);

// API
$router->mount('/api', function($r) {
    // listar
    $r->get('/orders', [OrderController::class, 'index']);
    // criar
    $r->post('/orders', [OrderController::class, 'store']);
    // atualizar status (PATCH /api/orders/{id}/status)
    $r->patch('/orders/(\d+)/status', function($id) {
        $ctrl = new OrderController();
        return $ctrl->updateStatus((int)$id);
    });
});

$router->run();
