<?php

header("Location: ../pdv.php");